package com.noetic.demo;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.junit4.SpringRunner;

import com.noetic.demo.model.Employee;
import com.noetic.demo.repository.EmployeeRepository;
import com.noetic.demo.service.EmployeeService;
import com.noetic.demo.service.EmployeeServiceImpl;

@RunWith(SpringRunner.class)
public class EmployeeServiceTest {

	@TestConfiguration
	static class EmployeeServiceImplTestContextConfig {

		@Bean
		public EmployeeService employeeService() {
			return new EmployeeServiceImpl();
		}
	}

	@Autowired
	EmployeeService employeeService;

	@MockBean
	EmployeeRepository employeeRepository;

	@Before
	public void setUp() {
		Employee emp = new Employee();
		emp.setFirstName("Ruwan");
		Mockito.when(employeeRepository.findByFirstName(emp.getFirstName())).thenReturn(emp);
	}

	@Test
	public void whenNameIsValid_empShouldFound() {
		String name = "Ruwan";
		Employee foundEmp = employeeService.findByFirstName(name);
		assertThat(foundEmp.getFirstName()).isEqualTo(name);
	}
}
