package com.noetic.demo;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.noetic.demo.controller.EmployeeController;
import com.noetic.demo.model.Department;
import com.noetic.demo.model.Employee;
import com.noetic.demo.service.DepartmentService;
import com.noetic.demo.service.EmployeeService;

@RunWith(SpringRunner.class)
@WebMvcTest(EmployeeController.class)
public class EmployeeControllerTest {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	EmployeeService employeeService;

	@MockBean
	DepartmentService departmentService;

	Department dept = new Department(1, "development");
	Employee emp = new Employee(1, "Ruwan", "Chathuranga", dept);

	@Test
	public void getEmployeById() throws Exception {

		Mockito.when(employeeService.findEmployeeById(Mockito.anyInt())).thenReturn(emp);

		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/employee/1").accept(MediaType.APPLICATION_JSON);

		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		System.out.println(result.getResponse().getContentAsString());
		String expected = "{empId:1, firstName:Ruwan, lastName:Chathuranga, department:{deptId:1,depName:development}}";

		JSONAssert.assertEquals(expected, result.getResponse().getContentAsString(), false);

	}

}
