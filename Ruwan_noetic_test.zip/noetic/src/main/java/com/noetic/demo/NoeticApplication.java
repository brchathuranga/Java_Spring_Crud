package com.noetic.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NoeticApplication {

	public static void main(String[] args) {
		SpringApplication.run(NoeticApplication.class, args);
	}
}
