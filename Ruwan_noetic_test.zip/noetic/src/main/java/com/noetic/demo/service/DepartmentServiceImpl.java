package com.noetic.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.noetic.demo.model.Department;
import com.noetic.demo.repository.DepartmentRepository;

@Service
public class DepartmentServiceImpl implements DepartmentService{

	@Autowired
	DepartmentRepository deptRepo;
	
	@Override
	public Department saveDepartment(Department department) {
		return deptRepo.saveAndFlush(department);
	}

	
	
	
}
