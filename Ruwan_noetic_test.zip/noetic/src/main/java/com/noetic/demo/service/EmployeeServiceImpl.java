package com.noetic.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.noetic.demo.model.Employee;
import com.noetic.demo.repository.EmployeeRepository;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	EmployeeRepository empRepo;

	@Override
	public List<Employee> findAll() {
		return empRepo.findAll();
	}

	@Override
	public Employee saveEmployee(Employee employee) {
		return empRepo.saveAndFlush(employee);
	}

	@Override
	public Employee findEmployeeById(int empId) {
		return empRepo.findOne(empId);
	}

	@Override
	public Employee findByFirstName(String firstName) {
		return empRepo.findByFirstName(firstName);
	}

}
