package com.noetic.demo.service;

import java.util.List;

import com.noetic.demo.model.Employee;

public interface EmployeeService {
	
	public Employee saveEmployee(Employee employee);
	
	public List<Employee> findAll();
	
	public Employee findEmployeeById(int empId);
	
	public Employee findByFirstName(String firstName);

}
