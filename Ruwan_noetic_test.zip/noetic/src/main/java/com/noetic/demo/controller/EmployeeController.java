package com.noetic.demo.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.noetic.demo.model.Department;
import com.noetic.demo.model.Employee;
import com.noetic.demo.service.DepartmentService;
import com.noetic.demo.service.EmployeeService;

@RestController
public class EmployeeController {

	@Autowired
	EmployeeService empService;

	@Autowired
	DepartmentService deptService;

	@GetMapping("/")
	public String getHome() {

		return "NOETIC HOME";
	}

	@GetMapping("/employees")
	List<Employee> findAllUsers() {
		List<Employee> employees = new ArrayList<>();
		employees = empService.findAll();
		return employees;
	}

	@GetMapping("/create")
	public Employee createEmployee() {

		Department dep1 = new Department();
		dep1.setDepName("Development");

		Employee emp1 = new Employee();
		emp1.setFirstName("Ruwan");
		emp1.setLastName("Chathuranga");

		emp1.setDepartment(deptService.saveDepartment(dep1));
		// returns to the front end just to make sure
		return empService.saveEmployee(emp1);
	}
	
	@GetMapping("/employee/{empId}")
	public Employee getEmployeById(@PathVariable String empId) {
		return empService.findEmployeeById(Integer.parseInt(empId));
	}

}
