package com.noetic.demo.service;

import com.noetic.demo.model.Department;

public interface DepartmentService {

	public Department saveDepartment(Department department);
	
	
}
